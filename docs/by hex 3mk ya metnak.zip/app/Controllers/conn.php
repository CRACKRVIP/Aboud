<?php

$servername = "localhost";
$username = "rrfun_1";
$password = "#SiIm3Ru+D-j";
$dbname = "rrfun_1";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>