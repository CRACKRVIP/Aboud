<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<!-- إضافة مكتبة Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<!-- تنسيقات CSS المخصصة -->
<style>
    /* تدرج لوني للخلفية */
    body {
        background: linear-gradient(0.97turn, #e3393988, #2a2225, #622f2f);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #ffffff;
    }

    /* تحسين شكل الكروت */
    .card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    }

    .card-header {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
        color: #ffffff;
        font-weight: bold;
        border-radius: 15px 15px 0 0;
    }

    .form-control {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #ffffff;
        transition: background 0.3s ease, border-color 0.3s ease;
    }

    .form-control:focus {
        background: rgba(255, 255, 255, 0.2);
        border-color: #23d5ab;
        box-shadow: 0 0 10px rgba(76, 195, 199, 0.5);
    }

    .btn {
        border-radius: 25px;
        transition: all 0.3s ease;
    }

    .btn-outline-dark {
        border-color: #4cc3c7;
        color: #4cc3c7;
    }

    .btn-outline-dark:hover {
        background: #4cc3c7;
        color: #ffffff;
    }

    /* تحسين الجدول */
    .table {
        color: #ffffff;
    }

    .table th {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
        color: #ffffff;
    }

    .table td {
        background: rgba(255, 255, 255, 0.1);
    }

    .table-hover tbody tr:hover {
        background: rgba(255, 255, 255, 0.2);
    }

    /* أنيميشن للكروت */
    .animate__animated {
        animation-duration: 1s;
    }
</style>

<div class="row animate__animated animate__fadeInUp">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-4 mb-3">
        <div class="card">
            <div class="card-header p-3" style="background: linear-gradient(0.9turn, #F50057, #F50057, #F50057);">
                <i class="bi bi-key"></i> Generate <?= $title ?>
            </div>
            <div class="card-body">
                <?= form_open() ?>
                <div class="form-group mb-3">
                    <label for="set_saldo"><i class="bi bi-wallet2"></i> إضافة رصيد جديد</label>
                    <div class="input-group mt-2">
                        <span class="input-group-text"><i class="bi bi-currency-dollar"></i></span>
                        <input type="number" class="form-control" name="set_saldo" id="set_saldo" minlength="1" maxlength="11" value="5">
                    </div>
                    <?php if ($validation->hasError('set_saldo')) : ?>
                        <small id="help-saldo" class="text-danger"><?= $validation->getError('set_saldo') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-outline-dark"><i class="bi bi-plus-circle"></i> إنشاء الكود</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <?php if ($code) : ?>
            <div class="card">
                <div class="card-header p-3" style="background: linear-gradient(0.9turn, #4cc3c7, #4cc3c7, #4cc3c7);">
                    <i class="bi bi-people"></i> عدد الموزعين الكلي <?= $total_code ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover text-center" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>السيريال</th>
                                    <th>المبلغ</th>
                                    <th>حول</th>
                                    <th>المالك</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($code as $c) : ?>
                                    <tr>
                                        <td><?= $c->id_reff ?></td>
                                        <td><?= substr($c->code, 1, 15) ?></td>
                                        <td>$<?= $c->set_saldo ?></td>
                                        <td><?= $c->used_by ?: '&mdash;' ?></td>
                                        <td><?= $c->created_by ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?= $this->endSection() ?>