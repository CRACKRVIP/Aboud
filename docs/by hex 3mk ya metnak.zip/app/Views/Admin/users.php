<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<!-- إضافة مكتبة Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<!-- تنسيقات CSS المخصصة -->
<style>
    /* خلفية متحركة */
    body {
        background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
    }

    @keyframes gradientBG {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    /* تأثيرات إضاءة */
    .glow-effect {
        box-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
    }

    /* حدود فاخرة */
    .fancy-border {
        border: 2px solid transparent;
        border-image: linear-gradient(45deg, #4cc3c7, #23d5ab);
        border-image-slice: 1;
    }

    /* تأثيرات hover على الأزرار */
    .btn-dark:hover {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
        color: white;
        transform: scale(1.05);
        transition: all 0.3s ease;
    }

    /* أيقونات حديثة */
    .bi {
        transition: transform 0.3s ease;
    }

    .bi:hover {
        transform: rotate(360deg);
    }

    /* إضافة رسوم متحركة للكروت */
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    /* تحسين الجدول */
    #datatable tbody tr {
        transition: background-color 0.3s ease;
    }

    #datatable tbody tr:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }

    /* تحسين الألوان */
    .alert-primary {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
        color: white;
    }

    .badge {
        font-size: 0.9rem;
        padding: 0.5rem 1rem;
        border-radius: 25px;
    }

    .badge-primary {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
    }

    .badge-dark {
        background: linear-gradient(45deg, #2a2225, #622f2f);
    }
</style>

<div class="row animate__animated animate__fadeInUp">
    <div class="col-lg-12">
        <div class="alert alert-primary glow-effect" role="alert">
            <i class="bi bi-info-circle"></i> قائمة المستخدمين
        </div>
        <div class="card shadow-sm fancy-border glow-effect">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-bordered table-hover text-center" style="width:100%">
                        <thead>
                            <tr>
                                <th scope="row">#</th>
                                <th>الاسم</th>
                                <th>الاسم الكامل</th>
                                <th>العضوية</th>
                                <th>الرصيد</th>
                                <th>الحالة</th>
                                <th>المالك</th>
                                <th>خيارات</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [
                [0, "desc"]
            ],
            ajax: "<?= site_url('admin/api/users') ?>",
            columns: [{
                    data: 'id',
                },
                {
                    data: 'username',
                },
                {
                    data: 'fullname',
                    render: function(data, type, row, meta) {
                        return (row.fullname ? row.fullname : '~');
                    }
                },
                {
                    data: 'level',
                },
                {
                    data: 'saldo',
                    render: function(data, type, row, meta) {
                        var textc = (row.level === 'Admin' ? 'primary' : 'dark');
                        var saldo = (row.level === 'Admin' ? '&mstpos;' : row.saldo);
                        return `<span class="badge text-${textc}">${saldo}</span>`;
                    }
                },
                {
                    data: 'status',
                    name: 'status',
                    render: function(data, type, row, meta) {
                        var act = `<span class="text-success">مفعل</span>`;
                        var ban = `<span class="text-danger">محظور</span>`;
                        return (row.status == 1 ? act : ban);
                    }
                },
                {
                    data: 'uplink',
                },
                {
                    data: null,
                    render: function(data, type, row, meta) {
                        return `<a href="${window.location.origin}/admin/user/${row.id}" class="btn btn-dark btn-sm glow-effect"><i class="bi bi-pencil"></i> تعديل</a> 
                                <a href="${window.location.origin}/admin/user/singledelete/${row.id}" class="btn btn-dark btn-sm glow-effect"><i class="bi bi-trash"></i> حذف</a>`;
                    }
                }
            ]
        });
    });
</script>

<?= $this->endSection() ?>