<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<!-- إضافة مكتبة Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<!-- تنسيقات CSS المخصصة -->
<style>
    /* خلفية متحركة */
    body {
        background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
    }

    @keyframes gradientBG {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    /* تأثيرات إضاءة */
    .glow-effect {
        box-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
    }

    /* حدود فاخرة */
    .fancy-border {
        border: 2px solid transparent;
        border-image: linear-gradient(45deg, #4cc3c7, #23d5ab);
        border-image-slice: 1;
    }

    /* تأثيرات hover على الأزرار */
    .btn-outline-dark:hover {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
        color: white;
        transform: scale(1.05);
        transition: all 0.3s ease;
    }

    /* أيقونات حديثة */
    .bi {
        transition: transform 0.3s ease;
    }

    .bi:hover {
        transform: rotate(360deg);
    }

    /* إضافة رسوم متحركة للكروت */
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    /* تحسين الجدول */
    .table {
        color: #ffffff;
    }

    .table th {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
        color: #ffffff;
    }

    .table td {
        background: rgba(255, 255, 255, 0.1);
    }

    .table-hover tbody tr:hover {
        background: rgba(255, 255, 255, 0.2);
    }

    /* أنيميشن للكروت */
    .animate__animated {
        animation-duration: 1s;
    }
</style>

<div class="row justify-content-center pt-3 animate__animated animate__fadeInUp">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-8 mb-3">
        <div class="card mb-5 fancy-border glow-effect">
            <div class="card-header p-3" style="background: linear-gradient(0.9turn, #4cc3c7, #4cc3c7, #4cc3c7); color: white;">
                <i class="bi bi-person-fill"></i> تعديل بيانات المستخدم &middot; <?= getName($target) ?>
            </div>
            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="user_id" value="<?= $target->id_users ?>">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="username" class="form-label">الاسم</label>
                        <input type="text" name="username" id="username" class="form-control glow-effect" placeholder="" aria-describedby="help-username" value="<?= old('username') ?: $target->username ?>">
                        <?php if ($validation->hasError('username')) : ?>
                            <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="fullname" class="form-label">الاسم الكامل</label>
                        <input type="text" name="fullname" id="fullname" class="form-control glow-effect" placeholder="" aria-describedby="help-fullname" value="<?= old('fullname') ?: $target->fullname ?>">
                        <?php if ($validation->hasError('fullname')) : ?>
                            <small id="help-fullname" class="form-text text-danger"><?= $validation->getError('fullname') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="level" class="form-label">العضوية</label>
                        <?php $sel_level = ['' => '&mdash; الخيارات &mdash;', '1' => 'ادمن', '2' => 'مشرف',]; ?>
                        <?= form_dropdown(['class' => 'form-select glow-effect', 'name' => 'level', 'id' => 'level'], $sel_level, $target->level) ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="status" class="form-label">حول</label>
                        <?php $sel_status = ['' => '&mdash; الخيارات &mdash;', '0' => 'محظور', '1' => 'مفعل',]; ?>
                        <?= form_dropdown(['class' => 'form-select glow-effect', 'name' => 'status', 'id' => 'status'], $sel_status, $target->status) ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="saldo" class="form-label">الرصيد</label>
                        <input type="number" name="saldo" id="saldo" class="form-control glow-effect" placeholder="" aria-describedby="help-saldo" value="<?= old('saldo') ?: $target->saldo ?>">
                        <?php if ($validation->hasError('saldo')) : ?>
                            <small id="help-saldo" class="form-text text-danger"><?= $validation->getError('saldo') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="uplink" class="form-label">المالك</label>
                        <input type="text" name="uplink" id="uplink" class="form-control glow-effect" placeholder="" aria-describedby="help-uplink" value="<?= old('uplink') ?: $target->uplink ?>">
                        <?php if ($validation->hasError('uplink')) : ?>
                            <small id="help-uplink" class="form-text text-danger"><?= $validation->getError('uplink') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12 mt-2">
                        <button type="submit" class="btn btn-outline-dark glow-effect"><i class="bi bi-arrow-repeat"></i> تحديث المعلومات</button>
                    </div>
                </div>
                <?= form_close() ?>
            </div>
        </div>

        <p class="text-muted text-center">
            <a href="<?= site_url('admin/manage-users') ?>" class="py-1 px-2 bg-white text-muted glow-effect"><small><i class="bi bi-arrow-left"></i> العودة الى المشرفين</small></a>
        </p>
    </div>
</div>

<?= $this->endSection() ?>