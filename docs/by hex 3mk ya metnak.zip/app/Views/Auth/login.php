<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<link rel="stylesheet" href="./v.css">
<!-- إضافة مكتبة Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

<style>
    /* حدود متدرجة وتأثيرات إضاءة */
    .gradient-border {
        border: 2px solid transparent;
        border-image: linear-gradient(45deg, #1e90ff, #00bfff); /* درجات الأزرق */
        border-image-slice: 1;
        box-shadow: 0 0 20px rgba(30, 144, 255, 0.5); /* إضاءة زرقاء */
    }

    /* تحسين الأزرار */
    .btn-primary {
        background: linear-gradient(45deg, #1e90ff, #00bfff); /* درجات الأزرق */
        border: none;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .btn-primary:hover {
        transform: scale(1.05);
        box-shadow: 0 0 20px rgba(30, 144, 255, 0.8); /* إضاءة زرقاء أقوى */
    }

    /* تحسين العناصر النصية */
    .text-muted {
        color: #6c757d !important;
    }

    .form-control {
        border: 1px solid #1e90ff; /* لون أزرق */
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .form-control:focus {
        border-color: #00bfff; /* لون أزرق فاتح */
        box-shadow: 0 0 10px rgba(30, 144, 255, 0.5); /* إضاءة زرقاء */
    }

    /* تحسين الشكل العام */
    .card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 10px;
    }

    /* تنسيق أيقونات Telegram */
    .telegram-icons {
        display: flex;
        justify-content: center;
        gap: 20px;
        margin-top: 10px;
    }

    .telegram-icon {
        font-size: 2rem;
        color: #1e90ff; /* لون أزرق */
        transition: transform 0.3s ease, color 0.3s ease;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        height: 50px;
        border: 2px solid #1e90ff; /* لون أزرق */
        border-radius: 50%; /* جعلها دائرية */
        background-color: rgba(30, 144, 255, 0.1); /* خلفية شفافة زرقاء */
        box-shadow: 0 0 10px rgba(30, 144, 255, 0.3); /* إضاءة زرقاء */
    }

    .telegram-icon:hover {
        transform: scale(1.2);
        color: #00bfff; /* لون أزرق فاتح */
        border-color: #00bfff; /* تغيير لون الحدود عند التمرير */
        box-shadow: 0 0 20px rgba(0, 191, 255, 0.5); /* إضاءة أقوى عند التمرير */
        animation: shake 0.5s ease-in-out; /* تأثير اهتزاز عند التمرير */
    }

    /* تعريف تأثير الاهتزاز */
    @keyframes shake {
        0%, 100% {
            transform: translateX(0);
        }
        25% {
            transform: translateX(-5px);
        }
        50% {
            transform: translateX(5px);
        }
        75% {
            transform: translateX(-5px);
        }
    }
</style>

<div class="d-flex flex-column min-vh-100 px-3 pt-4">
    <div class="row justify-content-center my-auto">
        <div class="col-md-8 col-lg-6 col-xl-5">
            <div class="card gradient-border" style="background-image: url('https://i.gifer.com/J4o.gif')">
                <div class="card-body p-4">

                    <div class="text-center mt-2">
                        <h5 class="text-muted">Welcome Back !</h5>
                        <p class="text-muted">Sign in to continue to Panel.</p>
                    </div>
                    <div class="p-2 mt-4">
                        <?= form_open() ?>

                        <div class="mb-3">
                            <label class="text-muted" class="form-label" for="username">Username</label>
                            <input type="text" class="form-control" name="username" id="username" aria-describedby="help-username" placeholder="Your username" required minlength="4">
                            <?php if ($validation->hasError('username')) : ?>
                            <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <div class="float-end">
                             <a href="forgot_passowrd" class="text-muted">Forgot password?</a>
                            </div>
                            <label class="text-muted" class="form-label" for="userpassword">Password</label>
                            <input type="password" class="form-control" name="password" id="password" aria-describedby="help-password" placeholder="Your password" required minlength="6">
                            <?php if ($validation->hasError('password')) : ?>
                            <small id="help-password" class="form-text text-danger"><?= $validation->getError('password') ?></small>
                            <?php endif; ?>
                        </div>

                        <div class="form-group mb-3">
                            <input type="hidden" class="form-control mt-2" name="ip" value="<?php echo $_SERVER['HTTP_USER_AGENT']; ?>" id="ip" aria-describedby="help-ip" required>

                            <?php if ($validation->hasError('ip')) : ?>
                            <small id="help-password" class="form-text text-danger"><?= $validation->getError('ip') ?></small>
                            <?php endif; ?>
                        </div>

                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes">
                            <label class="text-muted" class="form-check-label" for="auth-remember-check">Remember me</label>
                        </div>

                        <div class="mt-3 text-end">
                            <button type="submit" class="btn btn-primary w-100 waves-effect waves-light"><i class="bi bi-box-arrow-in-right"></i> Log in</button>
                        </div>
                        <?= form_close() ?>
                    </div>

                    <div class="mt-4 text-center">
                        <p class="text-muted" class="mb-0">Dont have an account ? <a href="<?= site_url('register') ?>" class="text-default">Sign Up Now</a> </p>
                        <!-- إضافة أيقونتي Telegram -->
                        <div class="telegram-icons">
                            <a href="https://t.me/R3PMOD" target="_blank" class="telegram-icon animate__animated animate__fadeInRight">
                                <i class="bi bi-telegram"></i> <!-- أيقونة Telegram من Bootstrap Icons -->
                            </a>
                            <a href="https://t.me/GT_GM" target="_blank" class="telegram-icon animate__animated animate__fadeInRight">
                                <i class="bi bi-telegram"></i> <!-- أيقونة Telegram من Bootstrap Icons -->
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="text-center text-muted p-4">
                    <p class="text-white-50">© <script>
                            document.write(new Date().getFullYear())
                        </script>Panel. Crafted with <i class="mdi mdi-heart text-danger"></i> by @R3PMOD</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- إضافة مكتبة SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(function(){
        <?php if(session()->has("error")) { ?>
            // تأثير الهز عند الخطأ
            $(".card").addClass("animate__animated animate__shakeX");

            // عرض رسالة الخطأ باستخدام SweetAlert2 مع أنيميشن
            Swal.fire({
                icon: 'error',
                title: 'Login Failed',
                text: '<?= session("error") ?>',
                confirmButtonText: 'Try Again',
                customClass: {
                    popup: 'animate__animated animate__bounceIn swal2-popup-custom', // أنيميشن للرسالة
                    container: 'swal2-dark', // إضافة كلاس للخلفية السوداء
                },
                background: '#000', // لون خلفية الرسالة (أسود)
                color: '#fff', // لون النص (أبيض)
                confirmButtonColor: '#1e90ff', // لون زر التأكيد (أزرق)
                showCloseButton: true, // إضافة زر إغلاق
                showClass: {
                    popup: 'animate__animated animate__fadeInDown', // تأثير ظهور الرسالة
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp', // تأثير اختفاء الرسالة
                },
            }).then((result) => {
                // إزالة تأثير الهز بعد عرض الرسالة
                $(".card").removeClass("animate__animated animate__shakeX");

                // إذا المستخدم داس على OK، نعيد تحميل الصفحة لإزالة الرسالة
                if (result.isConfirmed) {
                    window.location.reload(); // إعادة تحميل الصفحة
                }
            });
        <?php } ?>

        <?php if($validation->hasError('username') || $validation->hasError('password')) { ?>
            // عرض رسالة خطأ عند إدخال بيانات غير صحيحة
            Swal.fire({
                icon: 'error',
                title: 'Validation Error',
                text: 'Please check your username and password.',
                confirmButtonText: 'OK',
                customClass: {
                    popup: 'animate__animated animate__bounceIn swal2-popup-custom', // أنيميشن للرسالة
                    container: 'swal2-dark', // إضافة كلاس للخلفية السوداء
                },
                background: '#000', // لون خلفية الرسالة (أسود)
                color: '#fff', // لون النص (أبيض)
                confirmButtonColor: '#1e90ff', // لون زر التأكيد (أزرق)
                showCloseButton: true, // إضافة زر إغلاق
                showClass: {
                    popup: 'animate__animated animate__fadeInDown', // تأثير ظهور الرسالة
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp', // تأثير اختفاء الرسالة
                },
            }).then((result) => {
                // إذا المستخدم داس على OK، نعيد تحميل الصفحة لإزالة الرسالة
                if (result.isConfirmed) {
                    window.location.reload(); // إعادة تحميل الصفحة
                }
            });
        <?php } ?>
    });
</script>

<style>
    /* إضافة حدود زرقاء لرسائل SweetAlert2 */
    .swal2-popup-custom {
        border: 2px solid #1e90ff !important; /* حدود زرقاء */
        border-radius: 10px !important; /* زوايا مدورة */
    }
</style>

<?= $this->endSection() ?>