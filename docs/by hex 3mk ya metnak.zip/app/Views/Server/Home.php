<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
    /* تحسين الألوان والتأثيرات */
    .card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .card-header {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: white;
    }

    .btn-outline-primary, .btn-outline-dark {
        border-color: #1e90ff;
        color: #1e90ff;
        transition: all 0.3s ease;
    }

    .btn-outline-primary:hover, .btn-outline-dark:hover {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: white;
        transform: scale(1.05);
    }

    .form-control {
        border: 1px solid #1e90ff;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .form-control:focus {
        border-color: #4169e1;
        box-shadow: 0 0 10px rgba(30, 144, 255, 0.5);
    }

    .custom-file-input {
        border: 1px solid #1e90ff;
        border-radius: 5px;
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        color: white;
    }

    .custom-file-label {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid #1e90ff;
        color: white;
    }

    .text-muted {
        color: #a39c9b !important;
    }

    .btn-primary {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        border: none;
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        background: linear-gradient(45deg, #4169e1, #1e90ff);
        transform: scale(1.05);
    }
</style>

<?= $this->include('Layout/msgStatus') ?>
<div class="row">
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- jquery validation -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">File Upload <small>(with server-side)</small></h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <?php echo form_open('file_uploads', [ 'id' => 'quickForm', 'enctype' => 'multipart/form-data' ])  ?>
                        <form role="form" id="quickForm">
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">File Upload</label>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" name="file" required id="exampleInputFile">
                                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                        </div>
                                    </div>
                                    <p class="text-muted pt-2">simple file upload with server-side handling</p>
                                    <?php echo form_error('file'); ?>
                                </div>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                            <?php echo form_close()  ?>
                    </div>
                    <!-- /.card -->
                </div>
                <!--/.col (left) -->
                <!-- right column -->
                <div class="col-md-6">

                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <?php include viewPath('includes/footer'); ?>
<!-- jquery-validation -->
<script src="<?php echo $url->assets ?>plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo $url->assets ?>plugins/jquery-validation/additional-methods.min.js"></script>

<script type="text/javascript">
$(document).ready(function () {
  $.validator.setDefaults({
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });
  $('#quickForm').validate();

  // new exampleInputFile
  // $("#exampleInputFile").dropzone({});

});
</script>

<?= $this->endSection() ?>