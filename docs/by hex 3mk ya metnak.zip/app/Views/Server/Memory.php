<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
    /* تحسين الألوان والتأثيرات */
    .card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .card-header {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: white;
    }

    .btn-outline-primary, .btn-outline-dark {
        border-color: #1e90ff;
        color: #1e90ff;
        transition: all 0.3s ease;
    }

    .btn-outline-primary:hover, .btn-outline-dark:hover {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: white;
        transform: scale(1.05);
    }

    .form-control {
        border: 1px solid #1e90ff;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .form-control:focus {
        border-color: #4169e1;
        box-shadow: 0 0 10px rgba(30, 144, 255, 0.5);
    }

    .alert-primary {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: white;
    }

    .alert-success {
        background: linear-gradient(45deg, #28a745, #218838);
        color: white;
    }
</style>

<div class="row">
    <div class="col-lg-12">
        <div class="alert alert-primary" role="alert">
            <a class="" href="<?= site_url('Offensive') ?>">
                <i class="bi bi-bookmark-plus"></i> BT Status
            </a>
        </div>
        <?php if (session()->has('success')): ?>
            <div class="alert alert-success"><?= session()->get('success') ?></div>
        <?php endif ?>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card mb-3">
            <div class="card-header h6 p-3 bg-gradient-primary text-white">
                Mod Server Online_Offline
            </div>
            <div class="card-body">
                <?= form_open('update') ?>
                <h3>Update Function</h3>
                <label for="radios">Online:</label>
                <input type="radio" name="radios" value="1" checked>Yes
                <input type="radio" name="radios" value="0">No
                <br>
                <label for="myInput">Maintenance:</label>
                <input type="text" name="myInput" class="form-control">
                <br>
                <input type="submit" name="Update" value="Update" class="btn btn-outline-primary">
                <?= form_close() ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card mb-3">
            <div class="card-header h6 p-3 bg-gradient-primary text-white">
                Change Mod Name
            </div>
            <div class="card-body" style="padding-bottom:130px;">
                <?= form_open('update') ?>
                <label for="myInputKey">Time (in hours):</label>
                <input type="text" name="myInputKey" class="form-control">
                <br>
                <input type="submit" name="UpdateKey" value="Update Key" class="btn btn-outline-primary">
                <h3>Reset</h3>
                <input type="submit" name="Reset" value="Reset" class="btn btn-outline-dark">
                <?= form_close() ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card mb-3">
            <div class="card-header h6 p-3 bg-gradient-primary text-white">
                Change AIMBOT BULLET TRACK STATUS
            </div>
            <div class="card-body">
                <?= form_open('update') ?>
                <h3>Aimbot</h3>
                <input type="submit" name="onAimbot" value="Turn On" class="btn btn-outline-primary">
                <input type="submit" name="offAimbot" value="Turn Off" class="btn btn-outline-dark">
                <h3>Bullet Track</h3>
                <input type="submit" name="onBulletTrack" value="Turn On" class="btn btn-outline-primary">
                <input type="submit" name="offBulletTrack" value="Turn Off" class="btn btn-outline-dark">
                <h3>Memory</h3>
                <input type="submit" name="onMemory" value="Turn On" class="btn btn-outline-primary">
                <input type="submit" name="offMemory" value="Turn Off" class="btn btn-outline-dark">
                <?= form_close() ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card mb-3">
            <div class="card-header h6 p-3 bg-gradient-primary text-white">
                Instruction for Users
            </div>
            <div class="card-body">
                <!-- Add instructions here -->
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>