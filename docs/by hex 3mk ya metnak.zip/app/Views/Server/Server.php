<?php
include('conn.php');

// إنشاء الجدول Feature إذا لم يكن موجودًا
$checkTableQuery = "CREATE TABLE IF NOT EXISTS Feature (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ESP VARCHAR(3) NOT NULL,
    Item VARCHAR(3) NOT NULL,
    AIM VARCHAR(3) NOT NULL,
    SilentAim VARCHAR(3) NOT NULL,
    BulletTrack VARCHAR(3) NOT NULL,
    Memory VARCHAR(3) NOT NULL,
    Floating VARCHAR(3) NOT NULL,
    Setting VARCHAR(3) NOT NULL
)";
mysqli_query($conn, $checkTableQuery);

// for maintenance mode
$sql1 = "SELECT * FROM onoff WHERE id=1";
$result1 = mysqli_query($conn, $sql1);
$userDetails1 = mysqli_fetch_assoc($result1) ?? [];

// for ftext and status
$sql2 = "SELECT * FROM _ftext WHERE id=1";
$result2 = mysqli_query($conn, $sql2);
$userDetails2 = mysqli_fetch_assoc($result2) ?? [];

// for Features Status
$sql3 = "SELECT * FROM Feature WHERE id=1";
$result3 = mysqli_query($conn, $sql3);
$ModFeatureStatus = mysqli_fetch_assoc($result3) ?? [];
?>

<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>
<link rel="stylesheet" href="./v.css">
<style>
    /* تحسين الألوان والتأثيرات */
    .card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .card-header {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: white;
    }

    .btn-outline-primary, .btn-outline-dark {
        border-color: #1e90ff;
        color: #1e90ff;
        transition: all 0.3s ease;
    }

    .btn-outline-primary:hover, .btn-outline-dark:hover {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: white;
        transform: scale(1.05);
    }

    .form-control {
        border: 1px solid #1e90ff;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .form-control:focus {
        border-color: #4169e1;
        box-shadow: 0 0 10px rgba(30, 144, 255, 0.5);
    }

    .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px;
    }

    .switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: 0.4s;
        border-radius: 34px;
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: 0.4s;
        border-radius: 50%;
    }

    input:checked + .slider {
        background-color: #1e90ff;
    }

    input:checked + .slider:before {
        transform: translateX(26px);
    }
</style>

<div class="row">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
</div>

<?php if($user->level != 2) : ?>
<div class="col-lg-6">
    <div class="card mb-3">
        <div class="card-header h6 p-3">Online system</div>
        <div class="card-body">
            <?= form_open() ?>
            <input type="hidden" name="status_form" value="1">
            <div class="form-group mb-3">
                <label for="status">Current Server Mode : <font size="2" color="#a39c9b"><?php echo isset($userDetails1['status']) ? $userDetails1['status'] : 'N/A'; ?></font></label>
                <div class="input-group mb-3">
                    <label id="esp" class="hacks">
                        Server Status
                        <div class="switch">
                            <input type="checkbox" name="radios" id="radio" value="on" <?php if (isset($userDetails1['status']) && $userDetails1['status'] == "on"){?> checked="checked" <?php } ?>>
                            <span class="slider round"/>
                        </div>
                    </label>
                </div>
                <label for="modname">Server message : <font size="2" color="#a39c9b"><?php echo isset($userDetails1['myinput']) ? $userDetails1['myinput'] : 'N/A'; ?></font></label>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">Server Msg</span>
                    </div>
                    <textarea class="form-control" placeholder="Server message" name="myInput" id="myInput" rows="1"></textarea>
                </div>
                <?php if ($validation->hasError('modname')) : ?>
                    <small id="help-modname" class="text-danger"><?= $validation->getError('modname') ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group my-2">
                <button type="submit" class="btn btn-outline-primary">𝑼𝒑𝒅𝒂𝒕𝒆</button>
            </div>
            <?= form_close() ?>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="col-lg-6">
    <div class="card mb-3">
        <div class="card-header h6 p-3">Mod features</div>
        <div class="card-body">
            <?= form_open() ?>
            <input type="hidden" name="feature_form" value="1">
            <div class="form-group mb-3">
                <label for="status">Current Status : ESP - <font color="#a39c9b"><?php echo isset($ModFeatureStatus['ESP']) ? $ModFeatureStatus['ESP'] : 'N/A'; ?></font>  Items - <font color="#a39c9b"><?php echo isset($ModFeatureStatus['Item']) ? $ModFeatureStatus['Item'] : 'N/A'; ?></font> AIM - <font color="#a39c9b"><?php echo isset($ModFeatureStatus['AIM']) ? $ModFeatureStatus['AIM'] : 'N/A'; ?></font> SilentAim - <font color="#a39c9b"><?php echo isset($ModFeatureStatus['SilentAim']) ? $ModFeatureStatus['SilentAim'] : 'N/A'; ?></font> BulletTrack - <font color="#a39c9b"><?php echo isset($ModFeatureStatus['BulletTrack']) ? $ModFeatureStatus['BulletTrack'] : 'N/A'; ?></font> Memory - <font color="#a39c9b"><?php echo isset($ModFeatureStatus['Memory']) ? $ModFeatureStatus['Memory'] : 'N/A'; ?></font> Floating Texts - <font color="#a39c9b"><?php echo isset($ModFeatureStatus['Floating']) ? $ModFeatureStatus['Floating'] : 'N/A'; ?></font> Setting - <font color="#a39c9b"><?php echo isset($ModFeatureStatus['Setting']) ? $ModFeatureStatus['Setting'] : 'N/A'; ?></font></label>
                <label id="ESP" class="hacks">
                    Esp
                    <div class="switch">
                        <input type="checkbox" name="ESP" id="ESP" value="on" <?php if (isset($ModFeatureStatus['ESP']) && $ModFeatureStatus['ESP'] == "on"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
                <label id="Item" class="hacks">
                    Items
                    <div class="switch">
                        <input type="checkbox" name="Item" id="Item" value="on" <?php if (isset($ModFeatureStatus['Item']) && $ModFeatureStatus['Item'] == "on"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
                <label id="AIM" class="hacks">
                    AimBot
                    <div class="switch">
                        <input type="checkbox" name="AIM" id="AIM" value="on" <?php if (isset($ModFeatureStatus['AIM']) && $ModFeatureStatus['AIM'] == "on"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
                <label id="SilentAim" class="hacks">
                    Silent Aim
                    <div class="switch">
                        <input type="checkbox" name="SilentAim" id="SilentAim" value="on" <?php if (isset($ModFeatureStatus['SilentAim']) && $ModFeatureStatus['SilentAim'] == "on"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
                <label id="BulletTrack" class="hacks">
                    Bullet Track
                    <div class="switch">
                        <input type="checkbox" name="BulletTrack" id="BulletTrack" value="on" <?php if (isset($ModFeatureStatus['BulletTrack']) && $ModFeatureStatus['BulletTrack'] == "on"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
                <label id="Memory" class="hacks">
                    Memory
                    <div class="switch">
                        <input type="checkbox" name="Memory" id="Memory" value="on" <?php if (isset($ModFeatureStatus['Memory']) && $ModFeatureStatus['Memory'] == "on"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
                <label id="Floating" class="hacks">
                    Floating Text
                    <div class="switch">
                        <input type="checkbox" name="Floating" id="Floating" value="on" <?php if (isset($ModFeatureStatus['Floating']) && $ModFeatureStatus['Floating'] == "on"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
                <label id="Setting" class="hacks">
                    Settings
                    <div class="switch">
                        <input type="checkbox" name="Setting" id="Setting" value="on" <?php if (isset($ModFeatureStatus['Setting']) && $ModFeatureStatus['Setting'] == "on"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
                <div class="form-group my-2">
                    <button type="submit" class="btn btn-outline-dark">𝑼𝒑𝒅𝒂𝒕𝒆</button>
                </div>
            <?= form_close() ?>
        </div>
    </div>
</div>

<div class="col-lg-6">
    <div class="card mb-3">
        <div class="card-header h6 p-3">Modname</div>
        <div class="card-body">
            <?= form_open() ?>
            <input type="hidden" name="modname_form" value="1">
            <div class="form-group mb-3">
                <label for="modname">Current Mod Name: <font size="2" color="#a39c9b"><?php echo isset($row['modname']) ? $row['modname'] : 'N/A'; ?></font></label>
                <input type="text" name="modname" id="modname" class="form-control mt-2" placeholder="New modname" aria-describedby="help-modname" REQUIRED>
                <?php if ($validation->hasError('modname')) : ?>
                    <small id="help-modname" class="text-danger"><?= $validation->getError('modname') ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group my-2">
                <button type="submit" class="btn btn-outline-dark">𝑼𝒑𝒅𝒂𝒕𝒆</button>
            </div>
            <?= form_close() ?>
        </div>
    </div>
</div>

<div class="col-lg-6">
    <div class="card mb-3">
        <div class="card-header h6 p-3">Floating text</div>
        <div class="card-body">
            <?= form_open() ?>
            <input type="hidden" name="_ftext" value="1">
            <label for="status">
                Current Mod Status: 
                <font size="2" color="#a39c9b">
                    <?php echo isset($userDetails2['_status']) ? $userDetails2['_status'] : 'N/A'; ?>
                </font>
            </label>
            <div class="input-group mb-3">
                <label id="esp" class="hacks">
                    Mod status
                    <div class="switch">
                        <input type="checkbox" name="_ftextr" id="_ftextr" value="Safe" <?php if (isset($userDetails2['_status']) && $userDetails2['_status'] == "Safe"){?> checked="checked" <?php } ?>>
                        <span class="slider round"/>
                    </div>
                </label>
            </div>
            <div class="form-group mb-3">
                <label for="_ftext">Current Floating Text: <font size="2" color="#a39c9b"><?php echo isset($userDetails2['_ftext']) ? $userDetails2['_ftext'] : 'N/A'; ?></font></label>
                <input type="text" name="_ftext" id="_ftext" class="form-control mt-2" placeholder="New floating text" aria-describedby="help-_ftext" REQUIRED>
                <?php if ($validation->hasError('_ftext')) : ?>
                    <small id="help-_ftext" class="text-danger"><?= $validation->getError('_ftext') ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group my-2">
                <button type="submit" class="btn btn-outline-dark">𝑼𝒑𝒅𝒂𝒕𝒆</button>
            </div>
            <?= form_close() ?>
        </div>
    </div>
</div>
</br>
</div>
<?= $this->endSection() ?>