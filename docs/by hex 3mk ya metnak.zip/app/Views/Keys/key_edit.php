<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
    .card {
        border: none;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        background: linear-gradient(145deg, #1e1e1e, #2c2c2c);
        color: #ffffff;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5);
    }
    .card-header {
        border-radius: 20px 20px 0 0;
        background: linear-gradient(145deg, #1e90ff, #4169e1);
        color: white;
        font-weight: bold;
        padding: 1.5rem;
    }
    .btn-outline-dark {
        border-radius: 15px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        border-color: #1e90ff;
        color: #1e90ff;
    }
    .btn-outline-dark:hover {
        background-color: #1e90ff;
        color: white;
        transform: scale(1.05);
    }
    .btn-outline-dark:active {
        transform: rotate(360deg);
        transition: transform 0.5s ease;
    }
    .form-control {
        border-radius: 15px;
        padding: 12px 20px;
        border: 1px solid #444;
        transition: border-color 0.3s ease;
        background-color: #2c2c2c;
        color: #ffffff;
    }
    .form-control:focus {
        border-color: #1e90ff;
        box-shadow: 0 0 10px rgba(30, 144, 255, 0.5);
    }
    .input-group-text {
        border-radius: 15px 0 0 15px;
        background-color: #444;
        border: 1px solid #444;
        color: #ffffff;
    }
    .maxDev {
        background-color: #1e90ff;
        color: white;
        padding: 8px 15px;
        border-radius: 15px;
        display: inline-block;
        margin-left: 10px;
        font-size: 14px;
    }
    .rotate-icon {
        transition: transform 0.5s ease;
    }
    .rotate-icon:hover {
        transform: rotate(360deg);
    }
    .animated-text {
        background: linear-gradient(90deg, #1e90ff, #4169e1);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: text-animation 3s infinite alternate;
    }
    @keyframes text-animation {
        0% { transform: scale(1); }
        100% { transform: scale(1.05); }
    }

    /* إضافة خلفية للعناصر */
    .duration-bg {
        background-image: url('https://i.postimg.cc/3rLBGs9m/images-3.jpg');
        background-size: cover;
        background-position: center;
        padding: 10px;
        border-radius: 10px;
        color: white;
    }

    .custom-key-bg {
        background-image: url('https://i.postimg.cc/qRr9WGK9/images-2022-11-13-T201942-743.jpg');
        background-size: cover;
        background-position: center;
        padding: 10px;
        border-radius: 10px;
        color: white;
    }

    .bulk-keys-bg {
        background-image: url('https://i.postimg.cc/3rLBGs9m/images-3.jpg');
        background-size: cover;
        background-position: center;
        padding: 10px;
        border-radius: 10px;
        color: white;
    }

    /* تأثيرات إضافية */
    .ripple-effect {
        position: relative;
        overflow: hidden;
    }
    .ripple-effect:after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 5px;
        height: 5px;
        background: rgba(255, 255, 255, 0.5);
        opacity: 0;
        border-radius: 50%;
        transform: scale(1, 1) translate(-50%);
        transform-origin: 50% 50%;
    }
    .ripple-effect:focus:after {
        animation: ripple 0.5s ease-out;
    }
    @keyframes ripple {
        0% {
            transform: scale(0, 0);
            opacity: 1;
        }
        20% {
            transform: scale(25, 25);
            opacity: 1;
        }
        100% {
            opacity: 0;
            transform: scale(40, 40);
        }
    }

    /* تأثيرات الأيقونات */
    .icon-hover-effect {
        transition: transform 0.3s ease, color 0.3s ease;
    }
    .icon-hover-effect:hover {
        transform: scale(1.2);
        color: #1e90ff;
    }
</style>

<div class="row pb-5 justify-content-center">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-8 mb-3">
        <div class="card">
            <div class="card-header p-3">
                <div class="row align-items-center">
                    <div class="col pt-1 animated-text">
                        <i class="fas fa-user-edit icon-hover-effect"></i> تعديل معلومات المشترك
                    </div>
                    <div class="col">
                        <div class="text-end">
                            <a class="btn btn-sm btn-outline-light rotate-icon ripple-effect" href="<?= site_url('keys/generate') ?>">
                                <i class="fas fa-user-plus icon-hover-effect"></i>
                            </a>
                            <a class="btn btn-sm btn-outline-light rotate-icon ripple-effect" href="<?= site_url('keys') ?>">
                                <i class="fas fa-users icon-hover-effect"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= form_open('keys/edit') ?>

                <div class="row">
                    <input type="hidden" name="id_keys" value="<?= $key->id_keys ?>">
                    <?php if ($user->level == 1) : ?>
                        <div class="col-lg-6 mb-3">
                            <label for="game" class="form-label"><i class="fas fa-gamepad icon-hover-effect"></i> اللعبة</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-gamepad"></i></span>
                                <input type="text" name="game" id="game" class="form-control" placeholder="RandomKey" aria-describedby="help-game" value="<?= old('game') ?: $key->game ?>">
                            </div>
                            <?php if ($validation->hasError('game')) : ?>
                                <small id="help-game" class="text-danger"><?= $validation->getError('game') ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="user_key" class="form-label"><i class="fas fa-key icon-hover-effect"></i> المفتاح</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                                <input type="text" name="user_key" id="user_key" class="form-control" placeholder="RandomKey" aria-describedby="help-user_key" value="<?= old('user_key') ?: $key->user_key ?>">
                            </div>
                            <?php if ($validation->hasError('user_key')) : ?>
                                <small id="help-user_key" class="text-danger"><?= $validation->getError('user_key') ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3 duration-bg">
                            <label for="duration" class="form-label"><i class="fas fa-calendar-alt icon-hover-effect"></i> عدد الايام<small class="text-muted"></small></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                                <input type="number" name="duration" id="duration" class="form-control" placeholder="3" aria-describedby="help-duration" value="<?= old('duration') ?: $key->duration ?>">
                            </div>
                            <?php if ($validation->hasError('duration')) : ?>
                                <small id="help-duration" class="text-danger"><?= $validation->getError('duration') ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="max_devices" class="form-label"><i class="fas fa-mobile-alt icon-hover-effect"></i> عدد الاجهزة</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-mobile-alt"></i></span>
                                <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="3" aria-describedby="help-max_devices" value="<?= old('max_devices') ?: $key->max_devices ?>">
                            </div>
                            <?php if ($validation->hasError('max_devices')) : ?>
                                <small id="help-max_devices" class="text-danger"><?= $validation->getError('max_devices') ?></small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="col-md-6 mb-2" id="col-status">
                        <label for="status" class="form-label"><i class="fas fa-user-shield icon-hover-effect"></i> صلاحيات المفتاح</label>
                        <?php $sel_status = ['' => '&mdash; الخيارات &mdash;', '0' => 'محظور', '1' => 'مفعل',]; ?>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, $key->status) ?>
                        <?php if ($validation->hasError('status')) : ?>
                            <small id="help-status" class="text-danger"><?= $validation->getError('status') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="registrator" class="form-label"><i class="fas fa-user-tie icon-hover-effect"></i> المالك</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                            <input type="text" name="registrator" id="registrator" class="form-control" placeholder="nata" aria-describedby="help-registrator" value="<?= old('registrator') ?: $key->registrator ?>">
                        </div>
                        <?php if ($validation->hasError('registrator')) : ?>
                            <small id="help-registrator" class="text-danger"><?= $validation->getError('registrator') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="expired_date" class="form-label"><i class="fas fa-clock icon-hover-effect"></i> التاريخ<?= !$key->expired_date ? '' : ''  ?></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-clock"></i></span>
                            <input type="text" name="expired_date" id="expired_date" class="form-control" placeholder="<?= $time::now() ?>" aria-describedby="help-expired_date" value="<?= old('expired_date') ?: $key->expired_date ?>">
                        </div>
                        <?php if ($validation->hasError('expired_date')) : ?>
                            <small id="help-expired_date" class="text-danger"><?= $validation->getError('expired_date') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label for="devices" class="form-label"><i class="fas fa-mobile-alt icon-hover-effect"></i> الاجهزة <span class="maxDev"><?= $key_info->total ?>/<?= $key->max_devices ?></span> <small class="text-muted"></small></label>
                        <textarea class="form-control" name="devices" id="devices" rows="<?= ($key_info->total > $key->max_devices) ? 3 : $key_info->total ?>"><?= old('devices') ?: ($key_info->total ? $key_info->devices : '') ?></textarea>
                        <?php if ($validation->hasError('devices')) : ?>
                            <small id="help-devices" class="text-danger"><?= $validation->getError('devices') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <button class="btn btn-outline-dark btnUpdate ripple-effect" disabled><i class="fas fa-sync-alt icon-hover-effect"></i> تحديث المعلومات</button>
                    </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var level = "<?= $user->level ?>";
        if (level != 1) $("#registrator, #expired_date, #devices").attr('disabled', true);
        $("input, select, textarea").change(function() {
            $(".btnUpdate").attr('disabled', false);
        });
    });
    var total = "<?= $key_info->total ?>";
    $("#max_devices").change(function() {
        $(".maxDev").html(total + '/' + $(this).val());
        $("#devices").attr('rows', $(this).val());
    });
</script>
<?= $this->endSection() ?>