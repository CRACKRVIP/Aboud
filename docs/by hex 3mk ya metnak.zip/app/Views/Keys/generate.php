<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<!-- إضافة مكتبة Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<!-- تنسيقات CSS المخصصة -->
<style>
    /* خلفية متحركة */
    body {
        background: linear-gradient(-45deg, #1e3c72, #2a5298, #23a6d5, #1e90ff);
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
    }

    @keyframes gradientBG {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    /* تأثيرات إضاءة */
    .glow-effect {
        box-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
    }

    /* حدود فاخرة */
    .fancy-border {
        border: 2px solid transparent;
        border-image: linear-gradient(45deg, #1e90ff, #4169e1);
        border-image-slice: 1;
    }

    /* تأثيرات hover على الأزرار */
    .btn-outline-light:hover {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: white;
        transform: scale(1.05);
        transition: all 0.3s ease;
    }

    /* أيقونات حديثة */
    .bi {
        transition: transform 0.3s ease;
    }

    .bi:hover {
        transform: rotate(360deg);
    }

    /* إضافة رسوم متحركة للكروت */
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    /* تحسين الألوان */
    .alert-success {
        background: linear-gradient(135deg, #1e1e2f, #2a2a40);
        color: #fff;
    }

    .btn-primary {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        border: none;
    }

    .btn-primary:hover {
        background: linear-gradient(45deg, #4169e1, #1e90ff);
    }

    /* تحسين الجدول */
    .table {
        color: #ffffff;
    }

    .table th {
        background: linear-gradient(45deg, #1e90ff, #4169e1);
        color: #ffffff;
    }

    .table td {
        background: rgba(255, 255, 255, 0.1);
    }

    .table-hover tbody tr:hover {
        background: rgba(255, 255, 255, 0.2);
    }

    /* أنيميشن للكروت */
    .animate__animated {
        animation-duration: 1s;
    }
</style>

<div class="row justify-content-center animate__animated animate__fadeInUp">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>
        <?php if (session()->getFlashdata('user_key')) : ?>
            <div class="alert alert-success shadow-lg animate-fade-in" role="alert" id="generated-code-box" style="background: linear-gradient(135deg, #1e1e2f, #2a2a40); color: #fff;">
                <div class="flex items-center">
                    <span class="font-bold">الجهاز:</span>
                    <strong class="mx-2"><?= session()->getFlashdata('max_devices') ?></strong>
                </div>
                <div class="flex items-center">
                    <span class="font-bold">الكود:</span>
                    <strong class="key-sensi mx-2" id="generated-code"><?= session()->getFlashdata('user_key') ?></strong>
                    <button class="btn btn-sm btn-outline-light ml-2" onclick="copyCode()">
                        <i class="bi bi-clipboard"></i> نسخ الكود
                    </button>
                </div>
                <div class="flex items-center">
                    <span class="font-bold">المدة:</span>
                    <strong class="mx-2"><?= session()->getFlashdata('duration') ?> ساعة</strong>
                </div>
                <div class="flex items-center">
                    <span class="font-bold">اللعبة:</span>
                    <strong class="mx-2"><?= session()->getFlashdata('game') ?></strong>
                </div>
            </div>
        <?php endif; ?>

        <div class="card shadow-lg border-0" style="background: linear-gradient(135deg, #1e1e2f, #2a2a40);">
            <div class="card-header p-3 bg-transparent text-white">
                <div class="row">
                    <div class="col pt-1">
                        <h5 class="card-title mb-0" style="font-size: 1.5rem; color: #6bd1ff;">إنشاء ترخيص</h5>
                    </div>
                    <div class="col text-end">
                        <a class="btn btn-sm btn-outline-light" href="<?= site_url('keys') ?>">
                            <i class="bi bi-people"></i> إدارة التراخيص
                        </a>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <?= form_open() ?>

                <div class="row">
                    <div class="form-group col-lg-6 mb-3">
                        <label for="game" class="form-label" style="color: #fff;">اللعبة</label>
                        <?= form_dropdown(['class' => 'form-select shadow-sm', 'name' => 'game', 'id' => 'game'], $game, old('game') ?: '') ?>
                        <?php if ($validation->hasError('game')) : ?>
                            <small id="help-game" class="text-danger"><?= $validation->getError('game') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-lg-6 mb-3">
                        <label for="max_devices" class="form-label" style="color: #fff;">العدد الأقصى للأجهزة</label>
                        <input type="number" name="max_devices" id="max_devices" class="form-control shadow-sm" placeholder="1" value="<?= old('max_devices') ?: 1 ?>">
                        <?php if ($validation->hasError('max_devices')) : ?>
                            <small id="help-max_devices" class="text-danger"><?= $validation->getError('max_devices') ?></small>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group mb-3">
                    <label for="duration" class="form-label" style="color: #fff;">المدة</label>
                    <?= form_dropdown(['class' => 'form-select shadow-sm', 'name' => 'duration', 'id' => 'duration'], $duration, old('duration') ?: '') ?>
                    <?php if ($validation->hasError('duration')) : ?>
                        <small id="help-duration" class="text-danger"><?= $validation->getError('duration') ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group mb-3">
                    <label for="code_type" class="form-label" style="color: #fff;">نوع الكود</label>
                    <select class="form-select shadow-sm" name="code_type" id="code_type">
                        <option value="auto" selected>أوتو</option>
                        <option value="menu">منيو</option>
                        <option value="normal">عادي</option>
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="hulala" class="form-label" style="color: #fff;">إنشاء مفاتيح متعددة</label>
                    <select class="form-select shadow-sm" id="hulala" name="loopcount">
                        <option value="5">1 مفتاح</option>
                        <option value="1">5 مفاتيح</option>
                        <option value="2">10 مفاتيح</option>
                        <option value="3">25 مفتاح</option>
                        <option value="3">50 مفتاح</option>
                        <option value="4">100 مفتاح</option>
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="estimation" class="form-label" style="color: #fff;">التكلفة المتوقعة</label>
                    <input type="text" id="estimation" class="form-control shadow-sm" placeholder="التكلفة الإجمالية" readonly>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-block shadow-lg" style="background: #6bd1ff; border: none;">
                        إنشاء
                    </button>
                </div>

                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var price = JSON.parse('<?= $price ?>');
        getPrice(price);

        // عند التحديد
        $("#max_devices, #duration, #game").change(function() {
            getPrice(price);
        });

        // حساب التكلفة
        function getPrice(price) {
            var device = $("#max_devices").val();
            var durate = $("#duration").val();
            var gprice = price[durate];
            if (gprice !== NaN) {
                var result = (device * gprice);
                $("#estimation").val(result);
            } else {
                $("#estimation").val('خطأ في الحساب');
            }
        }
    });

    function copyCode() {
        var text = document.getElementById("generated-code").innerText;
        navigator.clipboard.writeText(text).then(function() {
            showToast("تم نسخ الكود: " + text);
        }, function() {
            showToast("فشل نسخ الكود");
        });
    }

    function showToast(message) {
        var toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerText = message;
        document.body.appendChild(toast);
        setTimeout(function() {
            toast.remove();
        }, 3000);
    }
</script>
<?= $this->endSection() ?>