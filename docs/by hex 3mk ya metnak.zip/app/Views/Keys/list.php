<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center">
    <div class="row">
        <div class="col-lg-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
        <div class="col-lg-12">
            <div class="card shadow-sm bg-dark text-white"> <!-- الخلفية السوداء -->
                <div class="card-header bg-gradient-primary text-white"> <!-- تدرج لوني أزرق -->
                    <div class="row">
                        <div class="col pt-1">
                           <strong> Keys Registered </strong>
                        </div>
                        <div class="col text-end">
                            <div class="float-right">
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="bi bi-list"></i> Open Menu
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start bg-dark text-white" aria-labelledby="navbarDropdown"> <!-- الخلفية السوداء -->
                                            <div class="card-header bg-gradient-secondary text-white h6 p-3"> <!-- تدرج لوني ثانوي -->
                                                <li>
                                                    <a class="dropdown-item text-white" href="<?= site_url('keys/generate') ?>">
                                                        <i class="bi bi-plus-circle"></i>&nbsp; <button type="button" class="btn btn-outline-primary">Generate</button>
                                                    </a>
                                                </li>
                                                <br>
                                                <li>
                                                    <a class="dropdown-item text-white" href="<?= site_url('keys/alter') ?>">
                                                        <i class="bi bi-x-circle"></i>&nbsp; <button class="btn btn-outline-danger">Delete Expired</button>
                                                    </a>
                                                </li>
                                                <br>
                                                <li>
                                                    <a class="dropdown-item text-white" href="<?= site_url('keys/deleteKeys')  ?>">
                                                        <i class="bi bi-trash"></i>&nbsp;  <button class="btn btn-outline-danger">Delete All</button>
                                                    </a>
                                                </li>
                                                <br>
                                                <li>
                                                    <a class="dropdown-item text-white" href="<?= site_url('keys/start')  ?>">
                                                        <i class="bi bi-backspace-reverse"></i> &nbsp; <button class="btn btn-outline-warning">Delete Not Used</button>
                                                    </a>
                                                </li>
                                                <br>  
                                                <li>
                                                    <a class="dropdown-item text-white" href="<?= site_url('keys/resetAll') ?>">
                                                        <i class="bi bi-arrow-repeat"></i>&nbsp; <button class="btn btn-outline-info">Reset All Key</button>
                                                    </a>
                                                </li>
                                                <br>
                                                <li>
                                                    <a class="dropdown-item text-white" href="<?= site_url('keys/download/all')  ?>">
                                                        <i class="bi bi-cloud-download"></i> &nbsp;<button class="btn btn-outline-success">Download All Key </button>
                                                    </a>
                                                </li>
                                            </div>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-body bg-dark text-white"> <!-- الخلفية السوداء -->
                    <?php if ($keylist) : ?>
                        <div class="table-responsive">
                            <table id="datatable" class="table table-bordered table-hover text-center bg-dark text-white" style="width:100%"> <!-- الخلفية السوداء -->
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Game</th>
                                        <th>User Keys</th>
                                        <th>Devices</th>
                                        <th>Duration</th>
                                        <th>Expired</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    <?php else : ?>
                        <p class="text-center">Nothing keys to show</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<style>
    /* تدرج لوني أزرق */
    .bg-gradient-primary {
        background: linear-gradient(145deg, #1e90ff, #4169e1);
    }

    /* تدرج لوني ثانوي */
    .bg-gradient-secondary {
        background: linear-gradient(145deg, #6c757d, #495057);
    }

    /* تأثيرات hover على الأزرار */
    .btn-outline-primary:hover,
    .btn-outline-danger:hover,
    .btn-outline-warning:hover,
    .btn-outline-info:hover,
    .btn-outline-success:hover {
        transform: scale(1.05);
        transition: transform 0.3s ease;
    }

    /* تأثيرات على الكروت */
    .card {
        transition: box-shadow 0.3s ease;
    }

    .card:hover {
        box-shadow: 0 0 20px rgba(255, 255, 255, 0.3);
    }

    /* تأثيرات على الجدول */
    #datatable tbody tr {
        transition: background-color 0.3s ease;
    }

    #datatable tbody tr:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }

    /* تأثيرات على الأيقونات */
    .bi {
        transition: transform 0.3s ease;
    }

    .bi:hover {
        transform: rotate(360deg);
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [
                [0, "desc"]
            ],
            ajax: "<?= site_url('keys/api') ?>",
            columns: [{
                    data: 'id',
                    name: 'id_keys'
                },
                {
                    data: 'game',
                },
                {
                    data: 'user_key',
                    render: function(data, type, row, meta) {
                        var is_valid = (row.status == 'Active') ? "text-success" : "text-danger";
                        return `<span class="${is_valid} ">${(row.user_key ? row.user_key : '&mdash;')}</span> `;
                    }
                },
                {
                    data: 'devices',
                    render: function(data, type, row, meta) {
                        var totalDevice = (row.devices ? row.devices : 0);
                        return `<span id="devMax-${row.user_key}">${totalDevice}/${row.max_devices}</span>`;
                    }
                },
                {
                    data: 'duration',
                    render: function(data, type, row, meta) {
                        return row.duration;
                    }
                },
                {
                    data: 'expired',
                    name: 'expired_date',
                    render: function(data, type, row, meta) {
                        return row.expired ? `<span class="badge text-warning">${row.expired}</span>` : '( غير مسجل )';
                    }
                },
                {
                    data: null,
                    render: function(data, type, row, meta) {
                        var btnReset = `<button class="btn btn-outline-danger btn-sm" onclick="resetUserKey('${row.user_key}')"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="Reset key?"><i class="bi bi-arrow-repeat"></i></button>`;
                        var btnalterOne = `<button class="btn btn-outline-warning btn-sm" onclick="resetUserKey1('${row.user_key}')"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="DELETE KEY?"><i class="bi bi-trash"></i></button>`;
                        var btnEdits = `<a href="${window.location.origin}/keys/${row.id}" class="btn btn-outline-info btn-sm"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="Edit key information?"><i class="bi bi-pencil-square"></i></a>`;
                        return `<div class="d-grid gap-2 d-md-block">${btnReset} ${btnalterOne} ${btnEdits}</div>`;
                    }
                }
            ]
        });

        $("#blur-out").click(function() {
            if ($(".keyBlur").hasClass("key-sensi")) {
                $(".keyBlur").removeClass("key-sensi");
                $("#blur-out").html(`<i class="bi bi-eye"></i>`);
            } else {
                $(".keyBlur").addClass("key-sensi");
                $("#blur-out").html(`<i class="bi bi-eye-slash"></i>`);
            }
        });
    });

    function resetUserKey1(keys) {
        Swal.fire({
            title: 'ملاحظة',
            text: "هل انت متاكد ان تريد حذف المفتاح ؟",
            icon: 'warning',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'نعم'
        }).then((result) => {
            if (result.isConfirmed) {
                Toast.fire({
                    icon: 'info',
                    title: 'الرجاء الانتظار ...'
                })

                var base_url = window.location.origin;
                var api_url = `${base_url}/keys/resetAll`;
                $.getJSON(api_url, {
                        userkey: keys,
                        reset: 1
                    },
                    function(data, textStatus, jqXHR) {
                        if (textStatus == 'success') {
                            if (data.registered) {
                                if (data.reset) {
                                    $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
                                    Swal.fire(
                                        'بنجاح!',
                                        'تمت إعادة ضبط مفتاح جهازك.',
                                        'success'
                                    )
                                } else {
                                    Swal.fire(
                                        'فشل!',
                                        data.devices_total ? "ليس لديك أي حق الوصول إلى هذا المستخدم" : "تم إعادة ضبط جهاز مفتاح المستخدم بالفعل",
                                        data.devices_total ? 'error' : 'warning'
                                    )
                                }
                            } else {
                                Swal.fire(
                                    'فشل ❌',
                                    "مفتاح المستخدم لم يعد موجودآ",
                                    'error'
                                )
                            }
                        }
                    }
                );
            }
        });
    }

    function resetUserKey(keys) {
        Swal.fire({
            title: 'ملاحظة',
            text: "هل انت متاكد ان تريد اعادة تعيين المفتاح ؟",
            icon: 'warning',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'نعم',
        }).then((result) => {
            if (result.isConfirmed) {
                Toast.fire({
                    icon: 'info',
                    title: 'الرجاء الانتظار ...'
                })

                var base_url = window.location.origin;
                var api_url = `${base_url}/keys/reset`;
                $.getJSON(api_url, {
                        userkey: keys,
                        reset: 1
                    },
                    function(data, textStatus, jqXHR) {
                        if (textStatus == 'success') {
                            if (data.registered) {
                                if (data.reset) {
                                    $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
                                    Swal.fire(
                                        'بنجاح!',
                                        'تمت إعادة ضبط مفتاح جهازك.',
                                        'success'
                                    )
                                } else {
                                    Swal.fire(
                                        '❌ فشل',
                                        data.devices_total ? "ليس لديك أي حق الوصول إلى هذا المستخدم" : "تم إعادة ضبط جهاز مفتاح المستخدم بالفعل",
                                        data.devices_total ? 'error' : 'warning'
                                    )
                                }
                            } else {
                                Swal.fire(
                                    'فشل!',
                                    "مفتاح المستخدم لم يعد موجودآ",
                                    'error'
                                )
                            }
                        }
                    }
                );
            }
        });
    }
</script>

<?= $this->endSection() ?>