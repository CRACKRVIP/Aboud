<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<!-- إضافة مكتبة Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<!-- تنسيقات CSS المخصصة -->
<style>
    /* تدرج لوني للخلفية */
body {
    background: linear-gradient(0.97turn, #3399ff, #2a2225, #3366cc);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #ffffff;
}

    /* تحسين شكل الكروت */
    .card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    }

.card-header {
    background: linear-gradient(45deg, #1e90ff, #00bfff); /* ألوان زرقاء */
    color: #ffffff;
    font-weight: bold;
    border-radius: 15px 15px 0 0;
}

    .list-group-item {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #ffffff;
        transition: background 0.3s ease, transform 0.3s ease;
    }

    .list-group-item:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: translateX(10px);
    }

    /* تحسين الأيقونات */
    .list-group-item i {
        margin-right: 10px;
        font-size: 1.2rem;
    }

    /* تأثيرات النصوص */
    .badge {
        font-size: 1rem;
        padding: 0.5rem 1rem;
        border-radius: 25px;
    }

    /* أنيميشن للكروت */
    .animate__animated {
        animation-duration: 1s;
    }
</style>

<?= $this->include('Layout/msgStatus') ?>

<div class="row animate__animated animate__fadeInUp">
    <!-- Card 1: Panel Logged on this IP -->
    <div class="col-lg-3">
        <div class="card mb-3">
            <div class="card-header text-center">
                <i class="bi bi-laptop"></i> Panel Logged on this IP
            </div>
            <div class="card-body">
                <ul class="list-group list-hover mb-3">
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-globe"></i> IP Address
                        <span class="badge bg-danger">
                            <h5 id="gfg"></h5>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Card 2: User's and Key Details -->
    <div class="col-lg-3">
        <div class="card mb-3">
            <div class="card-header text-center">
                <i class="bi bi-people"></i> User's and Key Details
            </div>
            <div class="card-body">
                <ul class="list-group list-hover mb-3">
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-key"></i> Total Keys
                        <span class="badge bg-danger">
                            <h5><?= $keysAll ?></h5>
                        </span>
                    </li>
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-cart-check"></i> Sold Keys
                        <span class="badge bg-warning">
                            <h5><?= $usedKeys ?></h5>
                        </span>
                    </li>
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-cart"></i> Unused Keys
                        <span class="badge bg-warning">
                            <h5><?= $unusedKeys ?></h5>
                        </span>
                    </li>
                </ul>
                <ul class="list-group">
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-person"></i> Total Users
                        <span class="badge bg-success">
                            <h5><?= $userAll ?></h5>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Card 3: Information -->
    <div class="col-lg-3">
        <div class="card mb-3">
            <div class="card-header text-center">
                <i class="bi bi-info-circle"></i> Information
            </div>
            <div class="card-body">
                <ul class="list-group list-hover mb-3">
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-person-badge"></i> Roles
                        <span class="badge bg-danger">
                            <?= getLevel($user->level) ?>
                        </span>
                    </li>
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-currency-rupee"></i> Rupees
                        <span class="badge bg-warning">
                            ₹<?= $user->saldo ?>
                        </span>
                    </li>
                </ul>
                <ul class="list-group">
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-clock"></i> Login Time
                        <span class="badge bg-success">
                            <?= $time::parse(session()->time_since)->humanize() ?>
                        </span>
                    </li>
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-hourglass-split"></i> Auto Logout
                        <span class="badge bg-info">
                            <?= $time::now()->difference($time::parse(session()->time_login))->humanize() ?>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Card 4: Visitor Count -->
    <div class="col-lg-3">
        <div class="card mb-3">
            <div class="card-header text-center">
                <i class="bi bi-eye"></i> Your Visitor Count
            </div>
            <div class="card-body">
                <ul class="list-group list-hover mb-3">
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <i class="bi bi-bar-chart"></i> Counter
                        <span class="badge bg-danger">
                            <h5 id="CounterVisitor"></h5>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script>
    // جلب عنوان IP
    $.getJSON("https://api.ipify.org?format=json", function(data) {
        $("#gfg").html(data.ip);
    });

    // عداد الزوار
    var n = localStorage.getItem('on_load_counter');
    if (n === null) {
        n = 0;
    }
    n++;
    localStorage.setItem("on_load_counter", n);

    nums = n.toString().split('').map(Number);
    document.getElementById('CounterVisitor').innerHTML = '';
    for (var i of nums) {
        document.getElementById('CounterVisitor').innerHTML += '<span class="counter-item">' + i + '</span>';
    }
</script>

<?= $this->endSection() ?>