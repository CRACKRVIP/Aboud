<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<!-- إضافة مكتبة Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

<!-- تنسيقات CSS المخصصة -->
<style>
    /* تدرج لوني للخلفية */
    body {
        background: linear-gradient(0.97turn, #e3393988, #2a2225, #622f2f);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #ffffff;
    }

    /* تحسين شكل الكروت */
    .card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    }

    .card-header {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
        color: #ffffff;
        font-weight: bold;
        border-radius: 15px 15px 0 0;
    }

    .form-control {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #ffffff;
        transition: background 0.3s ease, border-color 0.3s ease;
    }

    .form-control:focus {
        background: rgba(255, 255, 255, 0.2);
        border-color: #23d5ab;
        box-shadow: 0 0 10px rgba(76, 195, 199, 0.5);
    }

    .btn {
        border-radius: 25px;
        transition: all 0.3s ease;
    }

    .btn-outline-primary {
        border-color: #4cc3c7;
        color: #4cc3c7;
    }

    .btn-outline-primary:hover {
        background: #4cc3c7;
        color: #ffffff;
    }

    .btn-dark {
        background: linear-gradient(45deg, #4cc3c7, #23d5ab);
        border: none;
    }

    .btn-dark:hover {
        background: linear-gradient(45deg, #23d5ab, #4cc3c7);
    }

    /* خط فاصل بين العناصر */
    .list-group-item {
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding: 1rem;
        transition: background 0.3s ease, transform 0.3s ease;
    }

    .list-group-item:last-child {
        border-bottom: none; /* إزالة الخط الفاصل من العنصر الأخير */
    }

    .list-group-item:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: translateX(10px);
    }

    /* أنيميشن للكروت */
    .animate__animated {
        animation-duration: 1s;
    }
</style>

<div class="row animate__animated animate__fadeInUp">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-6">
        <div class="card mb-3">
            <div class="card-header h6 p-3 bg-primary text-white">
                <i class="bi bi-shield-lock"></i> Change Password
            </div>
            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="password_form" value="1">
                <div class="form-group mb-2">
                    <label for="current"><i class="bi bi-key"></i> Current Password</label>
                    <input type="password" name="current" id="current" class="form-control mt-2" placeholder="Current Password">
                    <?php if ($validation->hasError('current')) : ?>
                        <small id="help-current" class="text-danger"><?= $validation->getError('current') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-2">
                    <label for="password"><i class="bi bi-key-fill"></i> New Password</label>
                    <input type="password" name="password" id="password" class="form-control mt-2" placeholder="New Password" aria-describedby="help-password">
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="text-danger"><?= $validation->getError('password') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-2">
                    <label for="password2"><i class="bi bi-key-fill"></i> Confirm Password</label>
                    <input type="password" name="password2" id="password2" class="form-control mt-2" placeholder="Confirm Password" aria-describedby="help-password2">
                    <?php if ($validation->hasError('password2')) : ?>
                        <small id="help-password2" class="text-danger"><?= $validation->getError('password2') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group my-2">
                    <button type="submit" class="btn btn-outline-primary"><i class="bi bi-arrow-repeat"></i> Change Password</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card mb-3">
            <div class="card-header h6 p-3 bg-dark text-white">
                <i class="bi bi-person-circle"></i> Account Information
            </div>
            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="fullname_form" value="1">
                <div class="form-group mb-3">
                    <label for="fullname"><i class="bi bi-person"></i> Full Name</label>
                    <input type="text" name="fullname" id="fullname" class="form-control mt-2" placeholder="@GT_GM" aria-describedby="help-fullname" value="<?= old('fullname') ?: ($user->fullname ?: '') ?>">
                    <?php if ($validation->hasError('fullname')) : ?>
                        <small id="help-fullname" class="text-danger"><?= $validation->getError('fullname') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group my-2">
                    <button type="submit" class="btn btn-dark"><i class="bi bi-check-circle"></i> Update Account</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>