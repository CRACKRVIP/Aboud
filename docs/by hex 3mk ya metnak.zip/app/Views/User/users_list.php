<?php if ($error = $this->session->flashdata('msg')) { ?>
    <!-- إضافة مكتبة SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // عرض رسالة SweetAlert2
        Swal.fire({
            icon: 'success', // نوع الأيقونة (success, error, warning, info)
            title: '<?= $error ?>', // نص الرسالة
            showConfirmButton: false, // إخفاء زر التأكيد
            timer: 3000, // إغلاق الرسالة تلقائيًا بعد 3 ثواني
            background: '#1a1a1a', // لون الخلفية
            color: '#ffffff', // لون النص
            iconColor: '#00ff88', // لون الأيقونة
            timerProgressBar: true, // شريط تقدم المؤقت
            toast: true, // عرض الرسالة كـ "Toast"
            position: 'top-end', // موقع الرسالة (أعلى اليمين)
        });
    </script>
<?php } ?>